'use strict'

class FishController {
    * index(request, response) {
    

        
    }
}
module.exports = FishController
