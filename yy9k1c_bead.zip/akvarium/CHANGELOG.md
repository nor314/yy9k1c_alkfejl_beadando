<a name="3.1.0"></a>
# [3.1.0](https://github.com/adonisjs/adonis-app/compare/3.0.0...v3.1.0) (2016-10-11)


### Bug Fixes

* **package:** add missing dependencies ([3f5e9a1](https://github.com/adonisjs/adonis-app/commit/3f5e9a1))


### Features

* **antl:** add config for adonis-antl ([6459d4b](https://github.com/adonisjs/adonis-app/commit/6459d4b))
* **auth:** update config to add uid and password ([5e47a3f](https://github.com/adonisjs/adonis-app/commit/5e47a3f))
* **command:** add route:list command ([a0246f2](https://github.com/adonisjs/adonis-app/commit/a0246f2))



<a name="3.0.0"></a>
# 3.0.0 (2016-06-26)


### Features

* **config:auth:** add configuration file for auth([8198ef4](https://github.com/adonisjs/adonis-app/commit/8198ef4))
