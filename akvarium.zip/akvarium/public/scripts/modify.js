function ajaxModify(url) {
  const headers = {
    'csrf-token': $('[name="_csrf"]').val()
  }
  return Promise.resolve(
    $.ajax({
      url,
      method: 'MODIFY',
      dataType: 'json',
      headers
    })
  )
}

function showConfirm(message){
    $modal = $('.confirm-modal')
    $modal.modal('show')

    let _reject, _resolve
    $('.modal-cancel').on('click',function(){
        _resolve(false);
    })
    $('.modal-ok').on('click',function(){
        _resolve(true);
    })

    return new Promise(function(resolve,reject){
        _reject = reject,
        _resolve = resolve
    })
}

$('#btnModify').on('click', function(e){
    e.preventDefault();
    showConfirm().then(resolve => {
        console.log(resolve)
        if(resolve){
            var url = '/ajax' + $(this).attr('href')
            ajaxModify(url)
                .then(function(data){
                    console.log('SIKER!')
                    console.log(data)
                    location.assign('/')
                })  
                .catch(function(error){
                    console.log('AJJAJ!')
                    console.log(error)
                })
        }
        })
})