'use strict'

const Schema = use('Schema')

class AdTableSchema extends Schema {

  up () {
    this.create('ad', (table) => {
      table.increments()
      table.text('title').notNullable()
      table.text('text').notNullable()
      table.integer('category_id').unsigned().references('id').inTable('categories')
      table.integer('user_id').unsigned().references('id').inTable('users')
      table.text('contact').notNullable()
      table.timestamps()
    })
  }

  down () {
    this.drop('ad')
  }

}

module.exports = AdTableSchema
