'use strict'

const Lucid = use('Lucid')

class Ad extends Lucid {

    static get table (){
        return 'ad';
    }
    category () {
        return this.belongsTo('App/Model/Category')
    }
}

module.exports = Ad
