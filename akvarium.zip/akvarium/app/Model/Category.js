'use strict'

const Lucid = use('Lucid')

class Category extends Lucid {
    fishes () {
    return this.hasMany('App/Model/Fish')
  }
}

module.exports = Category
