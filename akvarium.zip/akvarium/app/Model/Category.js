'use strict'

const Lucid = use('Lucid')

class Category extends Lucid {
    fishes () {
        return this.hasMany('App/Model/Fish')
    }
    ads () {
        return this.hasMany('App/Model/Ad')
    }
}

module.exports = Category
