'use strict'


const Route = use('Route')


Route.get('/register', 'UserController.register')
Route.get('/login', 'UserController.login')
Route.post('/register', 'UserController.doRegister')
Route.post('/login', 'UserController.doLogin')
Route.get('/logout', 'UserController.doLogout')

Route.get('/', 'FishController.welcome')
Route.get('/fishes', 'FishController.index')
Route.get('/fishes/:id', 'FishController.show')
Route.get('/ownFishes', 'FishController.ownList').middleware('auth')
Route.get('/fish/create', 'FishController.create').middleware('auth')
Route.post('/fish/create', 'FishController.doCreate').middleware('auth')
Route.get('/fishes/:id/edit', 'FishController.edit').middleware('auth')
Route.post('/fishes/:id/edit', 'FishController.doEdit').middleware('auth')
Route.get('/fishes/:id/delete', 'FishController.doDelete').middleware('auth')
Route.get('/search', 'FishController.search')

Route.get('/ads', 'AdController.index')
Route.get('/ads/:id', 'AdController.show')
Route.get('/ownAds', 'AdController.ownList').middleware('auth')
Route.get('/ads/create', 'AdController.create').middleware('auth')
Route.post('/ads/create', 'AdController.doCreate').middleware('auth')
Route.get('/ads/:id/edit', 'AdController.edit').middleware('auth')
Route.post('/ads/:id/edit', 'AdController.doEdit').middleware('auth')
Route.get('/ads/:id/delete', 'AdController.doDelete').middleware('auth')


Route.get('/search', 'FishController.search')




