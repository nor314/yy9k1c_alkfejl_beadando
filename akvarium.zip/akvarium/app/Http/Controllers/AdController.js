'use strict'

const Database = use('Database')
const Category = use('App/Model/Category')
const Ad = use('App/Model/Ad')
const Validator = use('Validator')

class AdController {

  * index(request, response) {
    const categories = yield Category.all()
    for(let category of categories) {
      const ads = yield category.ads().fetch();
      category.topAds = ads.toJSON();
    }

    yield response.sendView('ads', {
      name: '',
      categories: categories.toJSON()
    })  
  }

   * ownList(request, response) {

    const categories = yield Category.all()

    for(let category of categories) {
      const ads = yield category.ads().where('user_id',request.currentUser.id).fetch();
      category.topAds = ads.toJSON();
    }

    yield response.sendView('ads', {
      name: '',
      categories: categories.toJSON()
    })  
  } 

  * create (request, response) {
    const categories = yield Category.all()
    yield response.sendView('AdCreate', {
      categories: categories.toJSON()
    });
  }

  * doCreate (request, response) {
    const adData = request.except('_csrf');

    const rules = {
      title: 'required',
      text: 'required',
      category_id: 'required',
      contact: 'required'
    };

    const validation = yield Validator.validateAll(adData, rules)

    if (validation.fails()) {
      yield request
        .withAll()
        .andWith({errors: validation.messages()})
        .flash()
      response.redirect('back')
      return
    }

    adData.user_id = request.currentUser.id
    const ad = yield Ad.create(adData)
    response.redirect('/')
  }

  * edit (request, response) {
    const categories = yield Category.all()
    const id = request.param('id');
    const ad = yield Ad.find(id);

    if (request.currentUser.id !== ad.user_id) {
      response.unauthorized('Access denied.')
      return
    }


    yield response.sendView('adEdit', {
      categories: categories.toJSON(),
      ad: ad.toJSON()
    });
  }

  * doEdit (request, response) {
    const adData = request.except('_csrf');

    const rules = {
      title: 'required',
      text: 'required',
      category_id: 'required',
      contact: 'required'
    };

    const validation = yield Validator.validateAll(adData, rules)

    if (validation.fails()) {
      yield request
        .withAll()
        .andWith({errors: validation.messages()})
        .flash()
      response.redirect('back')
      return
    }

    const id = request.param('id');
    const ad = yield Ad.find(id);

    
    
    ad.title = adData.title;
    ad.text = adData.text; 
    ad.category_id = adData.category_id;
    ad.contact = adData.contact;

    yield ad.save()
    
    response.redirect('/')
  }

  * show (request, response) {
    const id = request.param('id');
    const ad = yield Ad.find(id);
    yield ad.related('category').load();

    yield response.sendView('adShow', {
      ad: ad.toJSON()
    })
  }

  * doDelete (request, response) {
    const id = request.param('id');
    const ad = yield Ad.find(id);

    if (request.currentUser.id !== ad.user_id) {
      response.unauthorized('Access denied.')
      return
    }

    yield ad.delete()
    response.redirect('/')
  }
  
}

module.exports = AdController
