'use strict'

const Database = use('Database')
const Category = use('App/Model/Category')
const Fish = use('App/Model/Fish')
const Validator = use('Validator')

class FishController {

  * index(request, response) {

    const categories = yield Category.all()

    for(let category of categories) {
      const fishes = yield category.fishes().fetch();
      category.topFishes = fishes.toJSON();
    }

    yield response.sendView('main', {
      name: '',
      categories: categories.toJSON()
    })  
  }

   * ownList(request, response) {

    const categories = yield Category.all()

    for(let category of categories) {
      const fishes = yield category.fishes().where('user_id',request.currentUser.id).fetch();
      category.topFishes = fishes.toJSON();
    }

    yield response.sendView('main', {
      name: '',
      categories: categories.toJSON()
    })  
  }

  * search(request, response) {

    const categories = yield Category.all()
    var keres = request.input('keres')

    for(let category of categories) {
      const fishes = yield category.fishes().fetch();
      var fishes2 = fishes.filter(i => i.name.indexOf(keres) >= 0)
      category.topFishes = fishes2.toJSON();
    }

    yield response.sendView('main', {
      name: '',
      categories: categories.toJSON()
    })  
  }
  
 

  * create (request, response) {
    const categories = yield Category.all()
    yield response.sendView('fishCreate', {
      categories: categories.toJSON()
    });
  }

  * doCreate (request, response) {
    const fishData = request.except('_csrf');

    const rules = {
      name: 'required',
      family: 'required',
      instructions: 'required',
      category_id: 'required'
    };

    const validation = yield Validator.validateAll(fishData, rules)

    if (validation.fails()) {
      yield request
        .withAll()
        .andWith({errors: validation.messages()})
        .flash()
      response.redirect('back')
      return
    }

    fishData.user_id = request.currentUser.id
    const fish = yield Fish.create(fishData)
    response.redirect('/')
  }

  * edit (request, response) {
    const categories = yield Category.all()
    const id = request.param('id');
    const fish = yield Fish.find(id);

    if (request.currentUser.id !== fish.user_id) {
      response.unauthorized('Access denied.')
      return
    }


    yield response.sendView('fishEdit', {
      categories: categories.toJSON(),
      fish: fish.toJSON()
    });
  }

  * doEdit (request, response) {
    const recipeData = request.except('_csrf');

    const rules = {
      name: 'required',
      family: 'required',
      instructions: 'required',
      category_id: 'required'
    };

    const validation = yield Validator.validateAll(fishData, rules)

    if (validation.fails()) {
      yield request
        .withAll()
        .andWith({errors: validation.messages()})
        .flash()
      response.redirect('back')
      return
    }

    const id = request.param('id');
    const fish = yield Fish.find(id);

    
    
    fish.name = fishData.name;
    fish.family = fishData.family; 
    fish.instructions = fishData.instructions;
    fish.category_id = fishData.category_id;

    yield fish.save()
    
    response.redirect('/')
  }

  * show (request, response) {
    const id = request.param('id');
    const fish = yield Fish.find(id);
    yield fish.related('category').load();
    // response.send(recipe.toJSON())

    yield response.sendView('fishShow', {
      fish: fish.toJSON()
    })
  }

  * doDelete (request, response) {
    const id = request.param('id');
    const fish = yield Fish.find(id);

    if (request.currentUser.id !== fish.user_id) {
      response.unauthorized('Access denied.')
      return
    }

    yield fish.delete()
    response.redirect('/')
  }
  
}

module.exports = FishController
